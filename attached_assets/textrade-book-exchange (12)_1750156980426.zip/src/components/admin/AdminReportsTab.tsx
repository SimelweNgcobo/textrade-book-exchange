
import EnhancedModerationDashboard from './EnhancedModerationDashboard';

const AdminReportsTab = () => {
  return <EnhancedModerationDashboard />;
};

export default AdminReportsTab;
